/*
*@André Pont De Anda
x23164034
*
*/


public class DebugOne2{
   /* This program displays a greeting */
   public static void main(String arg[]){
      System.out.println("Hello");
   }
}