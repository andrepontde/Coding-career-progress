/*
*@André Pont De Anda
x23164034
*FirstDebugProgram.java
*/

//class definition

public class FirstDebugProgramme{
	//main method

	public static void main(String args[]){

		System.out.println("I love Web Design");
		System.out.println("and I love Maths too!");

	}
}