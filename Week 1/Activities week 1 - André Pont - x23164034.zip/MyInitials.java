/**
MyInitials.java
@André Pont De Anda
x23164034
**/

public class MyInitials{
	public static void main(String args[]){
		System.out.println();
		System.out.println(" JJJJJJJ  PPPPPP");
		System.out.println("    J     P    P");
		System.out.println("    J     PPPPPP");
		System.out.println("    J     P     ");
		System.out.println("  JJJ     P     ");
		System.out.println();
	}
}